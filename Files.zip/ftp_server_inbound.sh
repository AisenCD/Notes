###############################################################################
#####
#####                            ftp_input.sh
#####
#####  Purpose: move incoming files from the Partner Directoies to an central
#####           directories and put some additional info to the file name
#####
#####
#####  Author: D. Zielinski
#####  Date  : 29. JULY 2016
#####
###############################################################################


# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script

# Directoy for script configuration
CONFIG_DIR_INBOUND=/hl/ec/shared/script/config/inbound.config
sed $'s/\r//' -i $CONFIG_DIR_INBOUND	# remove the "\r" at end of some lines

# include variables
. $SCRIPT_DIR/config/env.config

YEAR_MONTH_DAY=`date +"%Y/%m/%d"`

#------------------------------------------------------------------------------
#
#     Function: for each protocol sub dir (ftp, http) of "/hl/ec/shared/alternate/externTransfer"
#

processFile()
{
	# For all FTP Partner input Directories
	for FTP_PARTNER_INPUT in `cat $1`
	do		
		PARTNER_ID=`echo $FTP_PARTNER_INPUT | cut -f1 -d'|'`
		PARTNER_DIRECTORY_INTERN=`echo $FTP_PARTNER_INPUT | cut -f2 -d'|'`

		# if [ `find ${1}/${FTP_PARTNER_INPUT}/in -prune -empty` ]
		if [ `find $PARTNER_DIRECTORY_INTERN -prune -empty` ]
		then
			continue
		fi		
		
		LOG_FILE=${DIR_LOG}/${PARTNER_ID}.inbound.log

		echo `date +"%Y%m%d:%H%M%S"`:'  '0: - \'$PARTNER_ID\' - \( Partner Directory ${PARTNER_DIRECTORY_INTERN} \) >> $LOG_FILE

		# For all INCOMING files within this Parnter Directory --> move to ??? to further processing
		for input_file in `find ${PARTNER_DIRECTORY_INTERN}/ -type f`
		do
			MBID=`${SCRIPT_DIR}/createMBID`
			# # NEW FILE NAME: contains the FTP-PARTNER-ID within the file name --> <FTP_PARTNER_ID>.<ORIGINAL FILENAME>
			NEW_FILE_NAME=${PARTNER_ID}.${MBID}.`basename $input_file`
			DIR_INBOUND=${DIR_ROOT_FTP_PARTNER_INTERN}/${PARTNER_ID}/in/

			echo `date +"%Y%m%d:%H%M%S"`:'  '0: --- \'`basename $input_file`\' - \( Move File as $NEW_FILE_NAME to ${DIR_INBOUND} and copy to Data Repository \) >> $LOG_FILE

			cp $input_file ${DIR_DATA_REPOSITORY}/inbound/$NEW_FILE_NAME && mv $input_file ${DIR_INBOUND}/$NEW_FILE_NAME
		done
	done
}

#------------------------------------------------------------------------------

# Handle files from FTP partner
processFile $CONFIG_DIR_INBOUND


# # Handle files from FTP partner
# processFile $DIR_ROOT_FTP_PARTNER_EXTERN

# # Handle files from HTTP partner
# processFile $DIR_ROOT_HTTP_PARTNER_EXTERN
