##########################################################################
#                                                                        #
# Name     :          ftp_client.sh                      #
#                                                                        #
# Purpose  : File contains ftp partner configuration records             #
#                                                                        #
# Remark   : Partners are in alphabetical order                          #
#            Record fields are separated by '|'                          #
#------------------------------------------------------------------------#
#                                                                        #
##########################################################################


export LOG_FTP_OUT=${ROUTING_ID}.session_out
export LOG_STD_ERR=${ROUTING_ID}.std_err
export LOG_STD_OUT=${ROUTING_ID}.std_out
#LOG_FTP_CONNECTION=${ROUTING_ID}.log
LOG_FTP_CONNECTION=$LOG_FILE_FTP_PARTNER

# # echo (for debugging purposes)
# echo ROUTING_ID: $ROUTING_ID, USERNAME: $USERNAME, PASSWORD: $PASSWORD, PORT: $PORT, URL_SERVER: $URL_SERVER, SUB_SCRIPT: $SUB_SCRIPT, DEBUG_LEVEL: $DEBUG_LEVEL


LOCK_DIR=/tmp
TEMP_DIR=/tmp
FILE_LOCK=${LOCK_DIR}/${ROUTING_ID}
# Maximum time (minutes) for FILE_LOCK until it is going to delete
MAXLOCKS=10

###############################################################################
#
#                   Pre Definition of some usefull functions
#
#       'echoinfo' -> print message as "INFO" to log file <LOG_FTP_CONNECTION>
#
echoinfo() { printf "%-20s%-5s%-10s%s\n" "`date +'%Y-%m-%d %H:%M:%S'`" "INFO" "--- $PPID" "$*"  >> ${LOG_FTP_CONNECTION}; }
# -----------------------------------------------------------------------------
#
#       'echowarn' -> print message as "WARN" to log file <LOG_FTP_CONNECTION>
#
echowarn() { printf "%-20s%-5s%-10s%s\n" "`date +'%Y-%m-%d %H:%M:%S'`" "WARN" "--- $PPID" "$*"  >> ${LOG_FTP_CONNECTION}; }
# -----------------------------------------------------------------------------
#
#       'echoerr' -> print message as "ERR" to log file <LOG_FTP_CONNECTION> and also to <LOG_STD_ERR>
#
echoerr() { printf "%-20s%-5s%-10s%s\n" "`date +'%Y-%m-%d %H:%M:%S'`" "ERR" "--- $PPID" "$*" >&2  >> ${LOG_STD_ERR};
            printf "%-20s%-5s%-10s%s\n" "`date +'%Y-%m-%d %H:%M:%S'`" "ERR" "--- $PPID" "$*" >> ${LOG_FTP_CONNECTION}; }
# -----------------------------------------------------------------------------
#
# 'echofile' -> print complete file content with additional info for each line
#
echofile()
{
  FILE=$1
  TAG=$2
  test -f $FILE || exit 1
  old_IFS=$IFS              
  IFS=$'\n'    
  for line in `cat $FILE`
  do          
       printf "%-20s%-5s%-10s%s\n" "`date +'%Y-%m-%d %H:%M:%S'`" "${TAG}" "--- $PPID" "$line"
     # printf "%s%s\n" "`date +'%Y-%m-%d %H:%M:%S'` ${TAG} ---- $PPID " "$line"
  done          
  IFS=$old_IFS 
}
###############################################################################


###############################################################################
#
#       Ensure that ONLE ONE instance of the FTP Scripting for a ROUTING_ID  is runnig!
#       So if a LOCK file exist (FILE_LOCK) then a script for this ROUTING_ID 
#       is runnig at the moment. Otherwise set a LOCK file
#
if test -f $FILE_LOCK
then 
#  already active, check elapsed time (in minutes).
#  lockfile $FILE_LOCK contains the startdate/-time in minutes.
#  This value is compared to the current time in minutes.

	FILE_LOCK_TS=`date +%s -r $FILE_LOCK`
	NOW_TS=`date +%s`

	DIFFSEC=`expr \( $NOW_TS - $FILE_LOCK_TS \)`
	DIFFMIN=`expr \( $DIFFSEC \) / 60`    

    if [ $DIFFMIN -gt $MAXLOCKS ]
    then
		# ftp is too long active, escalate problem   
		echoerr "ftp lock error for host $ROUTING_ID"
		echoerr "ftp is still active since $DIFFMIN minutes"
		echoerr "allowed period is MAXLOCKS $MAXLOCKS minutes"	
		echoerr "Process ID is `cat $FILE_LOCK`"			
    else
		# ftp is still active, but within allowed period
		echowarn "ftp to host $ROUTING_ID still active since $DIFFSEC seconds. Process ID is `cat $FILE_LOCK` "
    fi

    # if no (parent) process for THIS lock file exists
    # delete the lock file
    if ! ps -p "`cat $FILE_LOCK`" >/dev/null
    then
   		rm $FILE_LOCK
   		echowarn "No PPID for lock file of $PART_ID exists. Delete the lock file" 
		echowarn "FTP session might be alive..." 
    fi
   
    exit 1

else
	# set lock ....
	# Parent process ID as content for the file
	perl -e 'print getppid' > $FILE_LOCK
fi

echoinfo START

###############################################################################
#
# make sure which files to be sent
#
#




###############################################################################
#
# the files to be sent in data repository
#
#







###############################################################################
#
#                         INVOKE FTP CLIENT SCRIPT
#
echo lftp -e \"debug -to ${LOG_FTP_CONNECTION} ${DEBUG_LEVEL}\" -u ${USERNAME},${PASSWORD} -p ${PORT} ${URL_SERVER} \< ${SUB_SCRIPT} >> ${LOG_FTP_CONNECTION}
lftp -e "debug -to ${LOG_FTP_CONNECTION} ${DEBUG_LEVEL}" -u ${USERNAME},${PASSWORD} -p ${PORT} ${URL_SERVER}  < ${SUB_SCRIPT} > ${LOG_STD_OUT} 2>> ${LOG_STD_ERR}
#
###############################################################################

test -s ${LOG_STD_OUT} && echofile ${LOG_STD_OUT} INFO >> ${LOG_FTP_CONNECTION} && rm ${LOG_STD_OUT}
test -s ${LOG_STD_ERR} && echofile ${LOG_STD_ERR} ERR >> ${LOG_FTP_CONNECTION}

rm $FILE_LOCK

#echoerr error
echoinfo STOP

###############################################################################
