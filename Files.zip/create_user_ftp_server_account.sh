########################################
###
###      create_user_ftp_account_.sh
###
###   Creates a new user FTP account 
###
###   Arguments:
###     -u USER_ID   (mandatory)
###     -p PASSWORD  (mandatory)
###
###
###   Author: D. Zielinski
###
########################################

# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script
CONFIG=/home/hlagit1/shared/script/config/

# include variables
. $SCRIPT_DIR/config/env.config

usage() { echo "Usage: $0 -u <NEW_USER> -p <PASSWORD>" 1>&2; exit 1;}

while getopts ":u:p:" opt; do
  case $opt in
    u) NEW_USER=$OPTARG;;
    p) INITIAL_PASSWORD=$OPTARG;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
  esac
done

# pruefen der mandatory parameter
if [ -z "${NEW_USER}" ] || 
   [ -z "${INITIAL_PASSWORD}" ]
then
    usage
fi

# get the user-id and the primary group-id of the working user (hlait1 / hlagip1)
# using for changing the owner and permissions for the ftp sub directories (s. below)
USER_ID=`id -u $WHO_AM_I`
GROUP_ID=`id -g $WHO_AM_I`

HOME_DIR=$DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}

checkDir()
{
   # if dir <$1> does not exist 
  if ! test -d $1
  then
       # created it
       mkdir $1 && echo "Directory $1 created" || echo "ERROR: Could not create Directory $1"
  fi
}

# create sub dirs for FTP 'extern' in home dir (Partner view)
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${NEW_USER}
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${NEW_USER}/in
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${NEW_USER}/out
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${NEW_USER}/temp

# create sub dirs for FTP 'intern' in home dir (Hapag view)
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}/in
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}/out
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}/temp

# update config file for inbound and outbound connections
echo "${NEW_USER}|/hl/ec/shared/alternate/externTransfer/ftp/${NEW_USER}/out" >> $CONFIG/outbound.config
echo "${NEW_USER}|/hl/ec/shared/alternate/externTransfer/ftp/${NEW_USER}/in" >> $CONFIG/inbound.config


# change ownership and permissions exclusive to the NEW_USER
chown -R ${USER_ID}:${GROUP_ID} $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER} 
chmod -R 740 $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}

# create new user within proftpd
echo dummy | ftpasswd --passwd --stdin --name $NEW_USER --uid $USER_ID -gid $GROUP_ID --home $HOME_DIR --shell /bin/false --file $AUTH_FILE

if test $? -eq 0
then
    echo Account $NEW_USER has been created
    echo NEW_USER: $NEW_USER 
    echo USER_ID: $USER_ID 
    echo GROUP_ID: $GROUP_ID 
    echo HOME_DIR: $HOME_DIR 
  
    echo try to set password...
    sleep 2

    # set password
    ${SCRIPT_DIR}/change_password_ftp_account.sh -u $NEW_USER -p $INITIAL_PASSWORD

else
    echo "Account '${NEW_USER}' has NOT been created cause error invoke 'ftpasswd'!"

    # roll back: delete the directories for this account
    if test -n "$DIR_ROOT_FTP_PARTNER_INTERN" && test -n "$NEW_USER"
    then
       rm -r $DIR_ROOT_FTP_PARTNER_INTERN/${NEW_USER} $DIR_ROOT_FTP_PARTNER_EXTERN/${NEW_USER}
    fi
fi

