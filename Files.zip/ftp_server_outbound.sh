###############################################################################
#####
#####                            ftp_output.sh
#####
#####  Purpose: move outgoing files to the Partner Directoies from 
#               ?????
#####
#####
#####  Author: D. Zielinski
#####  Date  : 22. AUGUST 2016
#####
###############################################################################


# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script


# include variables
. $SCRIPT_DIR/config/env.config

LOG_FILE_SCRIPT=$SCRIPT_DIR/slog/ftp_output.log


# Directoy for script configuration
CONFIG_DIR_OUTBOUND=/hl/ec/shared/script/config/outbound.config
sed $'s/\r//' -i $CONFIG_DIR_OUTBOUND	# remove the "\r" at end of some lines

# usiow01|/hl/ec/shared/alternate/externTransfer/ftp/usiow01/out
# yangai|/hl/ec/shared/alternate/externTransfer/ftp/yangai/out
# trevy02|/hl/ec/shared/alternate/externTransfer/ftp/trevy02/COPARN


# For all FTP Partner output Directories
for FTP_PARTNER_OUTPUT in `cat $CONFIG_DIR_OUTBOUND`
do
	PARTNER_ID=`echo $FTP_PARTNER_OUTPUT | cut -f1 -d'|'`
	PARTNER_DIRECTORY_EXTERN=`echo $FTP_PARTNER_OUTPUT | cut -f2 -d'|'`
	SCRIPT_1=`echo $FTP_PARTNER_OUTPUT | cut -f3 -d'|'`

	# if there is a special processing step of a partner (zip for example), then switch to a special script for furthur processing.
	if [ ! "$SCRIPT_1" == "" ];then
		$SCRIPT_1
	fi
		
	# if [ `find /hl/ec/shared/alternate/internTransfer/${PARTNER_ID}/out -prune -empty` ]
	if [ `find /hl/ec/shared/alternate/internTransfer/${PARTNER_ID}/out -prune -empty` ]
	then
		continue
	fi
		  
	LOG_FILE=${DIR_LOG}/${PARTNER_ID}.outbound.log

	#echo `date +"%Y%m%d:%H%M%S"`:'  '0: - \'$PARTNER_ID\' - \( Partner Directory ${DIR_ROOT_FTP_PARTNER_INTERN}/${PARTNER_ID}/out \) >> $LOG_FILE


	##########################################
	#    For all OUTGOING files within this Directory --> move to ??? to further processing
	#
	#for output_file in `find ${DIR_ROOT_FTP_PARTNER_INTERN}/${PARTNER_ID}/out -type f`
	for output_file in `find ${DIR_ROOT_FTP_PARTNER_INTERN}/${PARTNER_ID}/out -not -path '*/\.*' -type f`
	do
		echo `date +"%Y%m%d:%H%M%S"`:'  '0: --- \'$PARTNER_ID\' - \( Next file is $output_file \) >> $LOG_FILE

		##########################################
		#    Extract some Variables
		#
		OLD_FILE_NAME=`basename $output_file`
		# <ID_NUMBER> : Get the ID_NUMBER from the <NEW_FILE_NAME>, the SECOND LAST, separated by '.' (e. g. 0443957O_US315.531634707.327605896.1 -> 327605896)
		ID_NUMBER=`echo ${OLD_FILE_NAME} |  awk -F'.' '{print ( $(NF-1) )}'`
		# echo $ID_NUMBER
		
		# Check for <ID_NUMBER>
		if echo "$ID_NUMBER" | grep -q ^'-'
		then
				# <ID_NUBMER> WITH an '-' at the beginnig (e. g. '-1234') -> remove <ID_NUMBER> and <CLIENT-ID> from the filename, cut the '-' from the <ID_NUMBER> and take the rest for the ID_NUMBER
				 # Example: 'original_file_name.txt.-1933949.1'  --> 'original_file_name.txt'
				  NEW_FILE_NAME=`echo ${OLD_FILE_NAME%.-*}`
		   # Set ID Number without '-'
				  ID_NUMBER=`echo $ID_NUMBER | tr -d '-'`
		else
				 # <ID_NUBMER> WITHOUT an '-' at the beginnig (e. g. '1234') -> remove <CLIENT-ID> ONLY from the filename, take ID_NUMBER as it is

				 # <NEW_FILE_NAME> : <OLD_FILE_NAME> without the trailing ID_NUMBER (e. g. 0443957O_US315.531634707.327605896.1 -> 0443957O_US315.531634707.327605896)
			  NEW_FILE_NAME=`echo ${OLD_FILE_NAME%.*}`
		fi

	 
		# get the FTP PARTNER ID from the path...  the SECOND LAST, separated by '/'  ((e. g. "/A/B/C/D/<file>" --> "C" ))
		# FTP_PARTNER_ID=`echo $output_file | cut -f7 -d'/'`
		FTP_PARTNER_ID=`echo $output_file | awk -F'/' '{print ( $(NF-2) )}'`


		##########################################
		#    COPY File to the Data Repository
		#
		cp $output_file ${DIR_DATA_REPOSITORY}/outbound/${FTP_PARTNER_ID}.$NEW_FILE_NAME

		##########################################
		#    Check if Target-Directory exist
		#
		if ! test -d $PARTNER_DIRECTORY_EXTERN
		then
			 echo `date +"%Y%m%d:%H%M%S"`:'  '1: --- \'$PARTNER_ID\' - \( Warning: Directory $PARTNER_DIRECTORY_EXTERN is missing. Try to create \) >> $LOG_FILE
			 mkdir -p $PARTNER_DIRECTORY_EXTERN
		fi

		##########################################
		#    MOVE File to the <out> directory of the FTP Partner
		#
		echo `date +"%Y%m%d:%H%M%S"`:'  '0: --- \'$PARTNER_ID\' - \( Move $output_file to $PARTNER_DIRECTORY_EXTERN/${NEW_FILE_NAME} \) >> $LOG_FILE
		if mv $output_file $PARTNER_DIRECTORY_EXTERN/${NEW_FILE_NAME} 2> /tmp/${ID_NUMBER}.err
		then
			 # write 'OK' entry for Workflow
			 echo `date +"%Y%m%d:%H%M%S"`";${ID_NUMBER};FTP_SERVER;$FTP_PARTNER_ID;$NEW_FILE_NAME;OK" > ${DIR_IDS}/${ID_NUMBER}
			 echo `date +"%Y%m%d:%H%M%S"`:'  '0: --- \'$PARTNER_ID\' - \( Moved file \'${OLD_FILE_NAME}\' as \'${NEW_FILE_NAME}\' to $PARTNER_DIRECTORY_EXTERN \) >> $LOG_FILE
		else
			 # write 'FAILED' entry for Workflow
			 echo `date +"%Y%m%d:%H%M%S"`";${ID_NUMBER};FTP_SERVER;$FTP_PARTNER_ID;$NEW_FILE_NAME;FAILED" > ${DIR_IDS}/${ID_NUMBER}
			 `cat /tmp/${ID_NUMBER}.err` >> ${DIR_IDS}/${ID_NUMBER}
			 echo `date +"%Y%m%d:%H%M%S"`:'  '2: --- \'$PARTNER_ID\' - \( Moved file \'${OLD_FILE_NAME}\' has FAILED: `cat /tmp/${ID_NUMBER}.err` && rm /tmp/${ID_NUMBER}.err \) >> $LOG_FILE
		fi  


	done
done


