##########################################################################
#                                                                        
# Name     :		delete_user_ftp_client_account.sh
#
# Purpose  : Deletes the directories for a FTP client connection
#            ( FTP push by Hapag)
# 
# Arguments:
#            -r Routing-ID   (mandatory)
#
# Author    : D. Zielinski
#
############################################################################


# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script
CONFIG=/home/hlagit1/shared/script/config/

# include variables
. $SCRIPT_DIR/config/env.config

usage() { echo "Usage: $0 -r <ROUTING_ID>" 1>&2; exit 1;}

while getopts ":r:" opt; do
  case $opt in
    r) ROUTING_ID=$OPTARG;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
  esac
done

# pruefen der mandatory parameter
if [ -z "${ROUTING_ID}" ] 
then
    usage
fi


	# rm -r [...] be very carefully
	if test -n ${ROUTING_ID} && test -d $DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID}
	then
		cd $DIR_ROOT_FTP_PARTNER_EXTERN
              if test -d ./${ROUTING_ID}
              then
                 rm -rf ./${ROUTING_ID} && echo Directories under $DIR_ROOT_FTP_PARTNER_EXTERN for Routing-ID ${ROUTING_ID} has been deleted successfully
              else
			echo change directory to ${PWD}/${ROUTING_ID} not successful
		fi

		cd $DIR_ROOT_FTP_PARTNER_INTERN
              if test -d ./${ROUTING_ID}
              then
                 rm -rf ./${ROUTING_ID} && echo Directories under $DIR_ROOT_FTP_PARTNER_INTERN for Routing-ID ${ROUTING_ID} has been deleted successfully
              else
			echo change directory to ${PWD}/${ROUTING_ID} not successful
		fi
	else
		echo "Folder $DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID} does not exist"
	fi



