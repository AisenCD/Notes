##########################################################################
#                                                                        
# Name     :		create_user_ftp_client_account.sh
#
# Purpose  : Creates directories for a new FTP client connection
#            ( FTP push by Hapag)
# 
# Arguments:
#            -r Routing-ID   (mandatory)
#
# Author    : D. Zielinski
#
#########################################################################



# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script
CONFIG=/home/hlagit1/shared/script/config/

# include variables
. $SCRIPT_DIR/config/env.config

usage() { echo "Usage: $0 -r <ROUTING_ID>" 1>&2; exit 1;}

while getopts ":r:" opt; do
  case $opt in
    r) ROUTING_ID=$OPTARG;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
  esac
done

# pruefen der mandatory parameter
if [ -z "${ROUTING_ID}" ] 
then
    usage
fi

# get the user-id and the primary group-id of the working user (hlait1 / hlagip1)
# using for changing the owner and permissions for the ftp sub directories (s. below)
USER_ID=`id -u $WHO_AM_I`
GROUP_ID=`id -g $WHO_AM_I`

HOME_DIR=$DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID}

checkDir()
{
   # if dir <$1> does not exist 
  if ! test -d $1
  then
       # created it
       mkdir $1 && echo "Directory $1 created" || echo "ERROR: Could not create Directory $1"
  fi
}

# create sub dirs for FTP 'extern' in home dir (Partner view)
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${ROUTING_ID}
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${ROUTING_ID}/in
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${ROUTING_ID}/out
checkDir $DIR_ROOT_FTP_PARTNER_INTERN/${ROUTING_ID}/temp

# create sub dirs for FTP 'intern' in home dir (Hapag view)
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID}
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID}/in
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID}/out
checkDir $DIR_ROOT_FTP_PARTNER_EXTERN/${ROUTING_ID}/temp

# update config file for inbound and outbound connections
#echo "${ROUTING_ID}|/hl/ec/shared/alternate/externTransfer/ftp/${ROUTING_ID}/out" >> $CONFIG/outbound.config
#echo "${ROUTING_ID}|/hl/ec/shared/alternate/externTransfer/ftp/${ROUTING_ID}/in" >> $CONFIG/inbound.config

echo Directories for Routing-ID ${ROUTING_ID} has been created successfully

