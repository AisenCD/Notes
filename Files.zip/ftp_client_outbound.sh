##########################################################################
#                                                                        #
# Name     :          ftp_client_outbound.sh     	                 #
#                                                                        #
#                                                                        #
# Remark   : Some important ENVIRONMENT VARIALBLES are defined 
#            within the config file
#
#                   /hl/ec/shared/script/config/env.config
#
#
##########################################################################

SCRIPT_DIR=/hl/ec/shared/script

# include variables
. ${SCRIPT_DIR}/config/env.config

LOG_FILE_SCRIPT=${SCRIPT_DIR}/slog/ftp_client_outbound.log
FTP_CLIENT_OUTBOUND_CONFIG_FILE=${SCRIPT_DIR}/config/ftp_client_outbound.cfg



while read line
do
	if `echo "$line" | grep -q ^#`
       then
		#echo "skip comment line"
		continue
	fi	
	
	export ROUTING_ID=`echo $line | cut -f1 -d'|'`
	export URL_SERVER=`echo $line | cut -f2 -d'|'`
	export PORT=`echo $line | cut -f3 -d'|'`
	export USERNAME=`echo $line | cut -f4 -d'|'`
	export PASSWORD=`echo $line | cut -f5 -d'|'`
	export SUB_SCRIPT=`echo $line | cut -f6 -d'|'`
	export DEBUG_LEVEL=`echo $line | cut -f7 -d'|'`

	export LOG_FILE_FTP_PARTNER=${DIR_LOG}/${ROUTING_ID}.ftp_client.outbound.log
	
	MISSING=""
	
	if [ "$ROUTING_ID" == "" ]; then ROUTING_ID="???"; MISSING+=" ???$line"; fi
	if [ "$URL_SERVER" == "" ]; then MISSING+=" URL_SERVER"; fi
	if [ "$PORT" == "" ]; then PORT=21; fi # PORT set to default=21
	if [ "$USERNAME" == "" ]; then MISSING+=" USERNAME"; fi
	if [ "$PASSWORD" == "" ]; then MISSING+=" PASSWORD"; fi
	if [ "$SUB_SCRIPT" == "" ]; then MISSING+=" SUB_SCRIPT"; fi
	if [ "$DEBUG_LEVEL" == "" ]; then DEBUG_LEVEL=5; fi # DEBUG_LEVEL set to default=5
	

       ########################################################################################       
       #                Check for some input parameter
       

       # Check if ${DIR_SCRIPT_PARTNER}/$SUB_SCRIPT does exist
	if ! test -f "${DIR_SCRIPT_PARTNER}/${SUB_SCRIPT}"
       then
          echo `date +"%Y%m%d:%H%M%S"`:'  '2: Routing-ID \"$ROUTING_ID\": SUB_SCRIPT \"${DIR_SCRIPT_PARTNER}/${SUB_SCRIPT}\" does not exsit!\
                 Processing cancelled for this Routing-ID! Please use a valid file as parameter for \"$ROUTING_ID\" '->' SUB_SCRIPT within\
                 config file ${FTP_CLIENT_OUTBOUND_CONFIG_FILE} | tee -a ${LOG_FILE_FTP_PARTNER} ${LOG_FILE_SCRIPT} >/dev/null 
          continue 
       else
              # for variable 'SUB_SCRIPT': add with the directory where it is
		export SUB_SCRIPT=${DIR_SCRIPT_PARTNER}/${SUB_SCRIPT}
	fi
       

       ########################################################################################
       # If some mandatory parameter  missing for a <ROUTING_ID> --> log this inforomation and cancel processing for this <ROUTING_ID>
	if [ ! -z "$MISSING" ]
       then
          echo `date +"%Y%m%d:%H%M%S"`:'  '2: Routing-ID \"$ROUTING_ID\" missing following inputs:${MISSING}.\
                 Processing cancelled for this Routing-ID! Please add input parameter within\
                 config file ${FTP_CLIENT_OUTBOUND_CONFIG_FILE} | tee -a ${LOG_FILE_FTP_PARTNER} ${LOG_FILE_SCRIPT} >/dev/null 
          continue 
	fi

       ########################################################################################
       # check if there are files to process (ftp push to partner server)
       #   --> check for file existing within directory "<DIR_ROOT_FTP_PARTNER_INTERN>/$ROUTING_ID/out"

	AMOUNT_OF_FILES=`find ${DIR_ROOT_FTP_PARTNER_EXTERN}/${ROUTING_ID}/out -type f | wc -l`

	echo `date +"%Y%m%d:%H%M%S"`:'  '0: Partner Directory ${DIR_ROOT_FTP_PARTNER_INTERN}/${ROUTING_ID}/out  >> $LOG_FILE_FTP_PARTNER

	if test "${AMOUNT_OF_FILES}" -gt 0
	then
		echo `date +"%Y%m%d:%H%M%S"`:'  '0: There are ${AMOUNT_OF_FILES} file\(s\) waiting for send to the partner server >> $LOG_FILE_FTP_PARTNER 
		echo `date +"%Y%m%d:%H%M%S"`:'  '0: Start ftp_client_outbound_run.sh for Routing-ID \"$ROUTING_ID\"  | tee -a ${LOG_FILE_FTP_PARTNER} ${LOG_FILE_SCRIPT} >/dev/null

		. ${SCRIPT_DIR}/ftp_client_outbound_run.sh
	else
		continue
	fi



done < $FTP_CLIENT_OUTBOUND_CONFIG_FILE 
