########################################
###
###      change_password_ftp_account.sh
###
###   Change the password for an ftp user account
###
###   Author: D. Zielinski
###
########################################


# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script

# include variables
. $SCRIPT_DIR/config/env.config

usage() { echo "Usage: $0 -u <USER_ACCOUNT> -p <NEW_PASSWORD>" 1>&2; exit 1;}

while getopts ":u:p:" opt; do
  case $opt in
    u) USER_ACCOUNT=$OPTARG;;
    p) NEW_PASSWORD=$OPTARG;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
  esac
done

if [ -z "${USER_ACCOUNT}" ] || [ -z "${NEW_PASSWORD}" ]
then
    usage
fi

# change password
echo ${NEW_PASSWORD} | ftpasswd --change-password --passwd --stdin --name=${USER_ACCOUNT} --file $AUTH_FILE

if test $? -eq 0
then

       # if an old entry exist -> delete entry for this account from password database file 'ftppw.config'
       if grep -q "|${USER_ACCOUNT}|" $SCRIPT_DIR/config/ftppw.config
       then
          perl -ni -e "print unless /${USER_ACCOUNT}/" $SCRIPT_DIR/config/ftppw.config
       fi

	echo Password for Account: ${USER_ACCOUNT} has been changed to new password: ${NEW_PASSWORD}
	echo `date +"%Y%m%d:%H%M%S"`"|${USER_ACCOUNT}|${NEW_PASSWORD}" >> $SCRIPT_DIR/config/ftppw.config
else
	echo Could not changed password for Account: ${USER_ACCOUNT}
fi









