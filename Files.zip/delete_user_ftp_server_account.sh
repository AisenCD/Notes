########################################
###
###      delete_user_account.sh
###
###   Deletes an user account
###
###   Author: D. Zielinski
###
########################################


# Directory for Scripting expected in '/hl/ec/shared/script'  
SCRIPT_DIR=/hl/ec/shared/script
CONFIG=/home/hlagit1/shared/script/config/

# include variables
. $SCRIPT_DIR/config/env.config

usage() { echo "Usage: $0 -u <USER_ACCOUNT>" 1>&2; exit 1;}

while getopts ":u:" opt; do
  case $opt in
    u) USER_ACCOUNT=$OPTARG;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      exit 1
      ;;
  esac
done

if [ -z "${USER_ACCOUNT}" ] 
then
    usage
fi

# delete account in linux
ftpasswd --passwd --delete-user --name=$USER_ACCOUNT --file $AUTH_FILE

if test $? -eq 0
then
	# rm -r [...] be very carefully
	if test -n ${USER_ACCOUNT} && test -d $DIR_ROOT_FTP_PARTNER_EXTERN/${USER_ACCOUNT}
	then
		cd $DIR_ROOT_FTP_PARTNER_EXTERN
              if test -d ./${USER_ACCOUNT}
              then
                 rm -rf ./${USER_ACCOUNT}
              else
			echo change directory to ${PWD}/${USER_ACCOUNT} not successful
		fi

		cd $DIR_ROOT_FTP_PARTNER_INTERN
              if test -d ./${USER_ACCOUNT}
              then
                 rm -rf ./${USER_ACCOUNT}
              else
			echo change directory to ${PWD}/${USER_ACCOUNT} not successful
		fi

	# delete entry for this account from password database file 'ftppw.config'
	grep -q ${USER_ACCOUNT} $SCRIPT_DIR/config/ftppw.config && perl -ni -e "print unless /${USER_ACCOUNT}/" $SCRIPT_DIR/config/ftppw.config


	else
		echo "Folder $DIR_ROOT_FTP_PARTNER_EXTERN/${USER_ACCOUNT} does not exist"
	fi

else
	echo ERROR: delete of account $USER_ACCOUNT was not successful!!!
fi


# delete the entries in config files
grep -v "^$USER_ACCOUNT" $CONFIG/inbound.config > $CONFIG/inbound.config.tmp
mv $CONFIG/inbound.config.tmp $CONFIG/inbound.config

grep -v "^$USER_ACCOUNT" $CONFIG/outbound.config > $CONFIG/outbound.config.tmp
mv $CONFIG/outbound.config.tmp $CONFIG/outbound.config


